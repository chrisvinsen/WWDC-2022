//
//  File.swift
//  Against Rrr
//
//  Created by Christianto Vinsen on 19/04/22.
//

import Foundation

struct MinimalPairs {
    let text: String
    let altText: String
    let url: String
}

struct SoundOfText {
    let text: String
    let url: String
}
